const screens = [...document.querySelectorAll(".screen")];
const PASSWORD = "21112011";

function showScreen(name){
  screens.forEach(s => s.classList.remove("active"));
  document.getElementById("screen-" + name).classList.add("active");
  window.scrollTo({top:0, behavior:"smooth"});
}

function checkPassword(){
  const input = document.getElementById("password");
  const msg = document.getElementById("password-msg");
  if(input.value === PASSWORD){
    msg.textContent = "UNLOCKED. ✓";
    msg.style.color = "#91d5a7";
    setTimeout(() => showScreen("puzzle1"), 550);
  }else{
    msg.textContent = "Not quite… think about the hint. 👀";
    msg.style.color = "#ef8997";
    input.select();
  }
}

let foundDifferences = new Set();
function findDifference(btn, n){
  if(foundDifferences.has(n)) return;
  foundDifferences.add(n);
  btn.classList.add("found");
  document.getElementById("diff-count").textContent = foundDifferences.size;
  if(foundDifferences.size === 5){
    const msg = document.getElementById("puzzle1-msg");
    msg.textContent = "YOU FOUND ALL 5. ✓";
    msg.style.color = "#91d5a7";
    setTimeout(() => showScreen("fakeout"), 900);
  }
}

function checkSequence(){
  const a = document.getElementById("seq1").value.trim();
  const b = document.getElementById("seq2").value.trim();
  const c = document.getElementById("seq3").value.trim();
  const msg = document.getElementById("sequence-msg");
  if(a === "10" && b === "12" && c === "14"){
    msg.textContent = "CORRECT. ✓ Two puzzles down.";
    msg.style.color = "#91d5a7";
    setTimeout(() => showScreen("intro"), 850);
  }else{
    msg.textContent = "Not quite. Look at the pattern again. 👀";
    msg.style.color = "#ef8997";
  }
}

const choiceHTML = {
  1: `
    <div class="tiny">OPTION 01</div>
    <h2>A LITTLE LETTER. ♡</h2>
    <div class="letter">
      <p>Hey you. ♡</p>
      <p>If you somehow ended up opening this one, then I guess you deserve a proper letter.</p>
      <p>I don't really know how to put everything I want to say into a few sentences, because there are so many little things that make you special to me. Some are huge, some are ridiculously small, and some probably wouldn't make sense to anyone else.</p>
      <p>But that's kind of the point.</p>
      <p>There are things about you that I notice without even trying. The little things you say. The way you react to things. The random moments that somehow become my favorite moments.</p>
      <p>I hope you know that your presence matters.</p>
      <p>Even an ordinary day can feel a little different when you're around. And even when we're doing absolutely nothing, somehow it still feels worth remembering.</p>
      <p>So here's the part where I'm supposed to say something incredibly profound…</p>
      <p><b>I'm really glad you're here. 🫶</b></p>
      <p>And I'm really glad that, somewhere along the way, our paths crossed.</p>
      <p>Keep this little letter, okay? It was written especially for you. ♡</p>
      <p>— From someone who probably thinks about you more than they admit. :)</p>
    </div>
    <button class="primary" onclick="showScreen('choices')">BACK TO CHOICES</button>
  `,
  2: `
    <div class="tiny">OPTION 02</div>
    <h2>100 THINGS I LIKE ABOUT YOU</h2>
    <ol class="list100">
      ${[
        "Your smile.","The way you make ordinary conversations interesting.","Your sense of humor.","The little things you remember.","Your reactions when you're surprised.",
        "The way you can make me laugh without trying.","Your random thoughts.","The way you get excited about things you care about.","Your honesty.","Simply having you around.",
        "Your voice.","Your expressions.","Your little habits.","The way you tell stories.","Your patience when it matters.",
        "Your curiosity.","Your confidence.","Your softer side.","Your weird side.","The way you make a boring moment less boring.",
        "Your jokes.","Your laugh.","The way you look when you're concentrating.","The way you get excited.","Your kindness.",
        "The way you notice details.","Your opinions.","The fact that you have opinions.","Your ability to surprise me.","Your energy.",
        "The way you say certain words.","Your random messages.","The conversations that last way too long.","The conversations that start for no reason.","Your little victories.",
        "The way you celebrate things.","Your determination.","Your creativity.","Your imagination.","Your ability to make me curious.",
        "The way you listen.","The way you remember tiny details.","Your sense of adventure.","Your calm moments.","Your chaotic moments.",
        "The way you make me feel comfortable.","The fact that silence doesn't have to be awkward.","Your confidence when you know you're right.","Your stubbornness, sometimes. 😭","Your ability to make me laugh at the worst times.",
        "The way you care.","Your enthusiasm.","Your spontaneity.","Your sincerity.","Your little reactions.",
        "The way you get annoyed.","The way you recover from awkward moments.","Your random ideas.","Your good moods.","The way you can turn a normal day into a story.",
        "Your ambition.","Your dreams.","Your determination to improve.","The way you keep going.","Your sense of humor when things get weird.",
        "The little things that only you do.","The way you make me want to remember moments.","Your presence.","Your personality.","The way you make people curious about you.",
        "Your confidence.","Your imperfections.","The fact that you are completely yourself.","The way you can be serious and silly.","Your playful side.",
        "Your thoughtful side.","The way you react to compliments.","Your ability to make things memorable.","Your little surprises.","Your way of seeing things.",
        "Your enthusiasm for the things you love.","The way you make me smile.","The way you make me think.","The way you make me look forward to conversations.","Your honesty even when it's inconvenient.",
        "The way you make ordinary memories feel important.","The fact that there is always something new to learn about you.","The way you can be unpredictable.","The moments when you catch me off guard.","Your individuality.",
        "The way you make me care.","The way you make me want to stay.","The memories we've made.","The moments still waiting to happen.","Your presence in my life.",
        "The person you are becoming.","The person you already are.","And finally… simply because you're you. ♡"
      ].map((x,i)=>`<li>${x}</li>`).join("")}
    </ol>
    <button class="primary" onclick="showScreen('choices')">BACK TO CHOICES</button>
  `,
  3: `
    <div class="tiny">OPTION 03</div>
    <h2>THINGS THAT ANNOY ME 😭</h2>
    <p>Let's be honest. You are not perfect. Unfortunately. 💀</p>
    <ol>
      <li>When you ignore me.</li>
      <li>When you don't talk to me for ages.</li>
      <li>When you disappear in the middle of a conversation.</li>
      <li>When you make me wonder what you're thinking.</li>
      <li>When you act like you don't know you're being annoying.</li>
      <li>When you leave me waiting for a reply.</li>
      <li>When you make a joke and then refuse to explain it.</li>
      <li>When you somehow manage to be right at the most inconvenient time.</li>
      <li>When you pretend you didn't hear me.</li>
      <li>And honestly… the fact that I still end up smiling anyway. 🙄</li>
    </ol>
    <button class="primary" onclick="showScreen('choices')">BACK TO CHOICES</button>
  `,
  4: `
    <div class="tiny">OPTION 04</div>
    <h2>A MEMORY. 🫶</h2>
    <p>Maybe you're expecting one specific memory.</p>
    <p>A particular day.<br>A particular conversation.<br>A particular moment.</p>
    <p>But honestly?</p>
    <p><b>Every moment spent with you is a good memory.</b></p>
    <p>Even the completely ordinary ones.</p>
    <p>The conversations that went nowhere.<br>The stupid jokes.<br>The random little moments that probably seemed insignificant at the time.</p>
    <p>Those are the things that end up staying.</p>
    <p>So if you ask me what my favorite memory is…</p>
    <p>Maybe it's not one memory at all.</p>
    <p><b>Maybe it's simply having you there. ♡</b></p>
    <button class="primary" onclick="showScreen('choices')">BACK TO CHOICES</button>
  `,
  5: `
    <div class="tiny">OPTION 05</div>
    <h2>SOMETHING I'VE NEVER SAID BEFORE</h2>
    <p>There's something I've never really said properly.</p>
    <p><b>I genuinely like being with you here.</b></p>
    <p>Not because something exciting has to happen.</p>
    <p>Not because we have to be doing something special.</p>
    <p>I just like your company.</p>
    <p>I like the little conversations, the random moments, the comfortable silence, the stupid jokes, and all the things that don't seem important until you realize how much you enjoy them.</p>
    <p>I don't think I've ever properly told you that.</p>
    <p><b>So… there. Now you know. ♡</b></p>
    <button class="primary" onclick="showScreen('choices')">BACK TO CHOICES</button>
  `
};

function openChoice(n){
  if(n === 6){ showScreen("quiz"); return; }
  document.getElementById("choice-content").innerHTML = choiceHTML[n];
  showScreen("choice-content");
}

const questions = [
  {q:"What is my favorite color?", a:["Pink","Blue","Grey","Green"], correct:2},
  {q:"What is my favorite food?", a:["Pizza","Biryani","Momos","Pasta"], correct:2},
  {q:"What is something I could do for hours without getting bored?", a:["Watch movies","Listen to music","Play games","Sleep"], correct:1},
  {q:"What kind of music do I like the most?", a:["K-pop","Rock","Classical","EDM"], correct:0},
  {q:"What is one thing that annoys me the most?", a:["Being ignored","Being woken up","Losing games","Slow internet"], correct:0},
  {q:"If I could instantly travel anywhere, where would I choose to go?", a:["Japan","South Korea","Paris","New York"], correct:1},
  {q:"What is something that can instantly make me happy?", a:["Food","A surprise","A message from you","Money"], correct:3},
  {q:"Which describes me better?", a:["Extremely organized","Completely chaotic","Somewhere in between","Depends on the day 😭"], correct:1},
  {q:"What's something I secretly enjoy more than I admit?", a:["Compliments","Attention","Being right","Annoying people"], correct:1},
  {q:"What do you think matters most to me?", a:["Memories","Success","Money","The people I care about"], correct:1}
];
let qIndex=0, score=0;

function startQuiz(){
  qIndex=0; score=0;
  showQuestion();
  showScreen("question");
}
function showQuestion(){
  const q=questions[qIndex];
  document.getElementById("quiz-progress").textContent=`QUESTION ${qIndex+1} / ${questions.length}`;
  document.getElementById("question-text").textContent=q.q;
  const box=document.getElementById("answers");
  box.innerHTML="";
  document.getElementById("answer-feedback").textContent="";
  document.getElementById("next-question").classList.add("hidden");
  q.a.forEach((text,i)=>{
    const b=document.createElement("button");
    b.className="answer-btn";
    b.textContent=`${String.fromCharCode(65+i)}) ${text}`;
    b.onclick=()=>answerQuestion(i,b);
    box.appendChild(b);
  });
}
function answerQuestion(i, chosenBtn){
  const q=questions[qIndex];
  document.querySelectorAll(".answer-btn").forEach(b=>b.disabled=true);
  const buttons=[...document.querySelectorAll(".answer-btn")];
  buttons[q.correct].classList.add("correct");
  const feedback=document.getElementById("answer-feedback");
  if(i===q.correct){
    score++;
    chosenBtn.classList.add("correct");
    feedback.innerHTML=`🟢 <b>OH??? YOU KNOW ME. 😭❤️</b><br>Okayyy, I'm impressed.`;
  }else{
    chosenBtn.classList.add("wrong");
    feedback.innerHTML=`🔴 <b>MONSTER MODE ACTIVATED. 👹</b><br>HOW DO YOU NOT KNOW THIS?! 😭`;
  }
  document.getElementById("next-question").classList.remove("hidden");
}
function nextQuestion(){
  qIndex++;
  if(qIndex<questions.length) showQuestion();
  else showScore();
}
function showScore(){
  document.getElementById("score").textContent=score;
  let title="", message="";
  if(score>=9){title="YOU ACTUALLY KNOW ME. 😭❤️";message="I'm genuinely impressed. Seriously."}
  else if(score>=7){title="OKAY, YOU KNOW ME PRETTY WELL. 👀";message="I'll allow it."}
  else if(score>=5){title="HMMMM…";message="We clearly need to spend more time together. 😭"}
  else if(score>=3){title="WE NEED TO HAVE A TALK. 👹";message="Some of those answers were criminal."}
  else {title="WHO ARE YOU?! 😭";message="I have questions. So many questions."}
  document.getElementById("score-title").textContent=title;
  document.getElementById("score-message").textContent=message;
  showScreen("score");
}

let photoIndex=0;
const photos=[
  {src:"assets/photo1.jpg",caption:"Just look at you. ♡"},
  {src:"assets/photo2.jpg",caption:"Okay… why do you actually look this good? 😭"},
  {src:"assets/photo3.jpg",caption:"A little moment worth keeping."},
  {src:"assets/photo4.jpg",caption:"Another one for the collection. 🫶"},
  {src:"assets/photo5.jpg",caption:"And somehow, you keep getting cuter."}
];

function openEnvelope(){
  const env=document.getElementById("envelope");
  env.classList.add("open");
  document.getElementById("envelope-hint").textContent="Opening… ♡";
  setTimeout(()=>{photoIndex=0;renderPhoto();showScreen("photos")},900);
}
function renderPhoto(){
  const p=photos[photoIndex];
  const card=document.getElementById("photo-card");
  card.style.animation="none";
  void card.offsetWidth;
  card.style.animation="pop .65s cubic-bezier(.2,1.5,.4,1) both";
  document.getElementById("memory-photo").src=p.src;
  document.getElementById("photo-caption").textContent=p.caption;
  document.getElementById("photo-dots").textContent="● ".repeat(photoIndex+1)+"○ ".repeat(photos.length-photoIndex-1);
  const btn=document.querySelector(".photo-next");
  btn.textContent=photoIndex===photos.length-1 ? "FINISH ♡" : "NEXT ♡";
}
function nextPhoto(){
  if(photoIndex<photos.length-1){photoIndex++;renderPhoto();}
  else showScreen("end");
}
