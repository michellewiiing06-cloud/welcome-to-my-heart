# Welcome to My Heart

A static HTML/CSS/JavaScript surprise game.

## Run locally
Open `index.html` in a browser.

## GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html`, `styles.css`, `script.js`, and the `assets` folder.
3. In GitHub: Settings -> Pages -> Deploy from branch -> choose the main branch and `/root`.
4. Open the generated Pages URL.

## Important
The password is implemented in client-side JavaScript because this is a static GitHub Pages site. It is a fun gate, not secure authentication: anyone who inspects the source can find it.
